module.exports = {reactStrictMode: true};
