import {useEffect, useState} from 'react'
import axios from 'axios'
export default function Projekty(){
  const [projekty,setProjekty]=useState([])
  useEffect(()=>{axios.get(process.env.NEXT_PUBLIC_API_URL + '/projekty/').then(r=>setProjekty(r.data)).catch(()=>{})},[])
  return (<div style={{padding:20}}><h2>Projekty</h2><ul>{projekty.map(p=>(<li key={p.id}>{p.nazev} - {p.faze}</li>))}</ul></div>)
}
