import Link from 'next/link'
export default function Home(){return (<div style={{padding:20}}><h1>Montaz Studio</h1><p><Link href='/projekty'>Projekty</Link></p></div>)}
