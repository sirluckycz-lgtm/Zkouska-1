from rest_framework import viewsets, permissions
from .models import Zakaznik, Projekt, Fotka, Faktura
from .serializers import ZakaznikSerializer, ProjektSerializer, FotkaSerializer, FakturaSerializer

class ZakaznikViewSet(viewsets.ModelViewSet):
    queryset = Zakaznik.objects.all()
    serializer_class = ZakaznikSerializer
    permission_classes = [permissions.IsAuthenticated]

class ProjektViewSet(viewsets.ModelViewSet):
    queryset = Projekt.objects.all()
    serializer_class = ProjektSerializer
    permission_classes = [permissions.IsAuthenticated]

class FotkaViewSet(viewsets.ModelViewSet):
    queryset = Fotka.objects.all()
    serializer_class = FotkaSerializer
    permission_classes = [permissions.IsAuthenticated]

class FakturaViewSet(viewsets.ModelViewSet):
    queryset = Faktura.objects.all()
    serializer_class = FakturaSerializer
    permission_classes = [permissions.IsAuthenticated]
