from rest_framework import serializers
from .models import Zakaznik, Projekt, Fotka, Faktura

class FotkaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Fotka
        fields = '__all__'

class FakturaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Faktura
        fields = '__all__'

class ProjektSerializer(serializers.ModelSerializer):
    fotky = FotkaSerializer(many=True, read_only=True)
    faktury = FakturaSerializer(many=True, read_only=True)
    class Meta:
        model = Projekt
        fields = '__all__'

class ZakaznikSerializer(serializers.ModelSerializer):
    projekty = ProjektSerializer(many=True, read_only=True)
    class Meta:
        model = Zakaznik
        fields = '__all__'
