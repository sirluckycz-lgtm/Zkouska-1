from django.db import models
class Zakaznik(models.Model):
    jmeno = models.CharField('Jméno', max_length=200)
    email = models.EmailField('E-mail', blank=True, null=True)
    telefon = models.CharField('Telefon', max_length=50, blank=True, null=True)
    poznamka = models.TextField('Poznámka', blank=True, null=True)
    def __str__(self): return self.jmeno

class Projekt(models.Model):
    FAZE = [('lead','Lead'),('navrh','Návrh'),('schvaleni','Schválení'),('vyroba','Výroba'),('montaz','Montáž'),('hotovo','Hotovo')]
    zakaznik = models.ForeignKey(Zakaznik, on_delete=models.CASCADE, related_name='projekty', verbose_name='Zákazník')
    nazev = models.CharField('Název', max_length=300)
    faze = models.CharField('Fáze', max_length=50, choices=FAZE, default='lead')
    adresa = models.CharField('Adresa', max_length=500, blank=True, null=True)
    termin = models.DateTimeField('Termín', blank=True, null=True)
    def __str__(self): return f"{self.nazev} ({self.zakaznik})"

class Fotka(models.Model):
    projekt = models.ForeignKey(Projekt, on_delete=models.CASCADE, related_name='fotky', verbose_name='Projekt')
    obrazek = models.ImageField('Obrázek', upload_to='fotky/')
    popis = models.CharField('Popis', max_length=300, blank=True)
    nahrano = models.DateTimeField('Nahráno', auto_now_add=True)

class Faktura(models.Model):
    projekt = models.ForeignKey(Projekt, on_delete=models.CASCADE, related_name='faktury', verbose_name='Projekt')
    cislo = models.CharField('Číslo faktury', max_length=100)
    castka = models.DecimalField('Částka', max_digits=10, decimal_places=2)
    zaplaceno = models.BooleanField('Zaplaceno', default=False)
    vystavena = models.DateField('Vystaveno', auto_now_add=True)
