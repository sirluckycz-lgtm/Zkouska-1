from django.contrib import admin
from .models import Zakaznik, Projekt, Fotka, Faktura
admin.site.register(Zakaznik)
admin.site.register(Projekt)
admin.site.register(Fotka)
admin.site.register(Faktura)
