Rychlý start (Replit):
1) pip install -r requirements.txt
2) python manage.py migrate
3) python manage.py loaddata sample_data.json
4) python manage.py createsuperuser
5) python manage.py runserver 0.0.0.0:8080
